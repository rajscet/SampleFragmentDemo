package in.peacocktech.samplefragmentapp;


import android.support.v4.app.Fragment;

/**
 * Created by peacock on 25/1/17.
 */

public interface ChangeCurrentFragment {

    void onFragmentChangeListener(Fragment fragment, String tag);



}
